// This file is fixed; do not change it. The judge renders AuctionCard with
// items that are not in this list.

export type Auction = {
  id: number;
  title: string;
  image: string;
  /** The highest bid so far, in toman. */
  currentBid: number;
  bids: number;
  hoursLeft: number;
  condition: "new" | "used";
  /** Left out when the seller did not choose a city. */
  city?: string;
  /** Left out when the seller did not say; the buyer then pays for shipping. */
  freeShipping?: boolean;
};

export const auctions: Auction[] = [
  {
    id: 51842,
    title: "دوچرخهٔ کوهستان ۲۶ اینچ",
    image: "./items/bike.svg",
    currentBid: 18_500_000,
    bids: 23,
    hoursLeft: 2,
    condition: "used",
  },
  {
    id: 51907,
    title: "گوشی آیفون ۱۳، ۱۲۸ گیگ",
    image: "./items/phone.svg",
    currentBid: 41_200_000,
    bids: 37,
    hoursLeft: 4,
    condition: "used",
    city: "اصفهان",
    freeShipping: true,
  },
  {
    id: 52011,
    title: "کنسول پلی‌استیشن ۵ با دو دسته",
    image: "./items/console.svg",
    currentBid: 52_900_000,
    bids: 41,
    hoursLeft: 7,
    condition: "used",
    city: "مشهد",
    freeShipping: false,
  },
  {
    id: 52136,
    title: "کتاب‌های کنکور تجربی، دورهٔ کامل",
    image: "./items/books.svg",
    currentBid: 2_350_000,
    bids: 14,
    hoursLeft: 11,
    condition: "used",
    freeShipping: true,
  },
  {
    id: 52203,
    title: "میز تحریر چوبی با سه کشو",
    image: "./items/desk.svg",
    currentBid: 6_800_000,
    bids: 9,
    hoursLeft: 30,
    condition: "new",
    city: "شیراز",
  },
  {
    id: 52288,
    title: "فرش دستباف ۶ متری کاشان",
    image: "./items/rug.svg",
    currentBid: 96_000_000,
    bids: 6,
    hoursLeft: 52,
    condition: "new",
    city: "کاشان",
    freeShipping: true,
  },
];
