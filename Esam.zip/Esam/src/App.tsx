import AuctionCard from "./components/AuctionCard";
import FilterBar from "./components/FilterBar";
import SellerBadge from "./components/SellerBadge";
import TopBar from "./components/TopBar";
import { auctions } from "./data";
import { toFa } from "./format";

// Today's auctions. This file is fixed; do not change it.
// Every card receives its values as props, one by one. For an item without a
// city or without freeShipping the prop is undefined, and AuctionCard uses its
// default value.
export default function App() {
  return (
    <>
      <TopBar />
      <main className="page" id="auctions">
        <div className="page__head">
          <div>
            <h1 className="page__title">مزایده‌های داغ امروز</h1>
            <p className="page__lead">
              این مزایده‌ها تا سه روز دیگر تمام می‌شوند. پیش از پایان زمان،
              پیشنهادتان را ثبت کنید.
            </p>
          </div>
          <span className="page__count">{toFa(auctions.length)} مزایده</span>
        </div>
        <FilterBar />
        <div className="layout">
          <section className="auctions" aria-labelledby="auctions-title">
            <h2 className="sr-only" id="auctions-title">
              فهرست مزایده‌ها
            </h2>
            <div className="auctions__grid">
              {auctions.map((item) => (
                <AuctionCard
                  key={item.id}
                  title={item.title}
                  image={item.image}
                  currentBid={item.currentBid}
                  bids={item.bids}
                  hoursLeft={item.hoursLeft}
                  condition={item.condition}
                  city={item.city}
                  freeShipping={item.freeShipping}
                />
              ))}
            </div>
          </section>
          <aside className="sidebar">
            <section className="side-card">
              <h2 className="side-card__title">فروشنده‌های برتر این هفته</h2>
              <SellerBadge name="مهدی رضایی" rating={4.9} verified />
              <SellerBadge name="سمیرا کاظمی" rating={4.8} verified />
              <SellerBadge name="علی نوروزی" rating={4.6} />
            </section>
            <section className="side-card">
              <h2 className="side-card__title">
                مزایده در ای‌سام چطور کار می‌کند؟
              </h2>
              <ol className="steps">
                <li>برای کالایی که می‌خواهید پیشنهاد قیمت ثبت کنید.</li>
                <li>اگر کسی پیشنهاد بالاتری بدهد، خبرتان می‌کنیم.</li>
                <li>وقتی زمان مزایده تمام شود، بالاترین پیشنهاد برنده است.</li>
              </ol>
            </section>
          </aside>
        </div>
      </main>
    </>
  );
}
