// The site's top bar. This file is fixed; do not change it.
export default function TopBar() {
  return (
    <header className="topbar">
      <div className="topbar__inner">
        <a className="topbar__brand" href="#top">
          <img className="topbar__logo" src="./logo.png" alt="ای‌سام" />
        </a>
        <nav className="topbar__nav" aria-label="بخش‌های ای‌سام">
          <a href="#auctions" className="is-current" aria-current="page">
            مزایده‌ها
          </a>
          <a href="#buy-now">خرید فوری</a>
          <a href="#stores">فروشگاه‌ها</a>
        </nav>
        <label className="topbar__search">
          <span className="sr-only">جست‌وجو در ای‌سام</span>
          <input type="search" placeholder="جست‌وجو در ای‌سام" readOnly />
        </label>
        <a className="topbar__sell" href="#sell">
          فروش کالا
        </a>
      </div>
    </header>
  );
}
