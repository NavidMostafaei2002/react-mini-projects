import { formatToman, toFa } from "../format";
import { auctions } from "../data";

const CONDITION_LABELS: Record<string, string> = {
  new: "نو",
  used: "کارکرده",
};
// TODO: complete the props type. Besides the title, a card receives:
//   image, currentBid (in toman), bids, hoursLeft, condition ("new" or "used"),
//   and two optional props, city and freeShipping.

export type AuctionCardProps = {
  title: string;
  image: string;
  currentBid: number;
  bids: number;
  hoursLeft: number;
  condition: "new" | "used";
  city?: string;
  freeShipping?: boolean;
};

// TODO: return the card markup from the statement, built only from the props.
//   - The condition label and its modifier class come from `condition`.
//   - A card without a city shows the default city, and a card without
//     freeShipping says that the buyer pays for shipping.
//   - formatToman and toFa, imported above, write the numbers.
// src/components/SellerBadge.tsx shows typed props with a default value.
export default function AuctionCard({
  title,
  image,
  currentBid,
  bids,
  hoursLeft,
  condition,
  city = "تهران",
  freeShipping = false,
}: AuctionCardProps) {
  return (
    <>
      <article className="auction-card">
        <div className="auction-card__media">
          <img className="auction-card__image" src={image} alt={title} />
          <span
            className={`auction-card__condition auction-card__condition--${condition}`}
          >
            {CONDITION_LABELS[condition]}
          </span>
        </div>
        <h3 className="auction-card__title">{title}</h3>
        <p className="auction-card__bid">
          بالاترین پیشنهاد <strong>{formatToman(currentBid)}</strong>
        </p>
        <ul className="auction-card__meta">
          <li>{toFa(bids)} پیشنهاد</li>
          <li>{toFa(hoursLeft)} ساعت مانده</li>
          <li>{city}</li>
        </ul>
        <p className="auction-card__shipping">
          {freeShipping ? "ارسال رایگان" : "هزینهٔ ارسال با خریدار"}
        </p>{" "}
        <button className="auction-card__cta" type="button">
          ثبت پیشنهاد
        </button>
      </article>
    </>
  );
}
