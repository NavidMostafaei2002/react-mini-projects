import { formatRating } from "../format";

// A worked example of a component with typed props:
//   - SellerBadgeProps lists every prop with its type; "?" makes verified optional
//   - the parameter destructures the props, and verified = false is the default
//     used when App.tsx leaves verified out
//   - the markup reads each prop inside braces
// App.tsx renders three of these in the sidebar.
// This file is fixed; do not change it.
export type SellerBadgeProps = {
  name: string;
  rating: number;
  verified?: boolean;
};

export default function SellerBadge({ name, rating, verified = false }: SellerBadgeProps) {
  return (
    <div className="seller">
      <span className="seller__avatar" aria-hidden="true">
        {name.charAt(0)}
      </span>
      <div className="seller__info">
        <strong className="seller__name">{name}</strong>
        <span className="seller__rating">امتیاز {formatRating(rating)} از ۵</span>
        <span className={verified ? "seller__id seller__id--verified" : "seller__id"}>
          {verified ? "احراز هویت شده" : "احراز هویت نشده"}
        </span>
      </div>
    </div>
  );
}
