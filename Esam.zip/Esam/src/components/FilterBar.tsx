// The category chips above the list; they do not filter anything yet.
// This file is fixed; do not change it.
const CATEGORIES = ["همه", "موبایل و تبلت", "کنسول و بازی", "خانه و آشپزخانه", "ورزش و سفر", "کتاب و لوازم تحریر"];

export default function FilterBar() {
  return (
    <div className="filters">
      <div className="filters__chips" role="group" aria-label="دسته‌ها">
        {CATEGORIES.map((label, i) => (
          <button key={label} className={i === 0 ? "chip is-active" : "chip"} type="button" aria-pressed={i === 0}>
            {label}
          </button>
        ))}
      </div>
      <p className="filters__sort">
        مرتب‌سازی: <strong>نزدیک‌ترین پایان</strong>
      </p>
    </div>
  );
}
