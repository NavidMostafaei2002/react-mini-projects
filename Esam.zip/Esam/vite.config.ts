import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Files in public/ are served from the site root. The pages refer to them
// with relative paths such as "./logo.svg" so that the same markup also works
// in the static copies the exercise screenshots are taken from.
export default defineConfig({
  plugins: [react()],
});
