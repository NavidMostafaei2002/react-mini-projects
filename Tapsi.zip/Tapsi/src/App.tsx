import { useState } from "react";
import Panel from "./components/Panel";
import ServiceOption from "./components/ServiceOption";
import TopBar from "./components/TopBar";
import TripSummary from "./components/TripSummary";
import { rideOptions, trip, wallet } from "./data";
import { formatToman } from "./format";

// The ride request page. This file is fixed; do not change it.
// The selected ride type lives here, in App's state. The options only report
// a click through onSelect; App stores the new id and renders them again.
export default function App() {
  const [selected, setSelected] = useState(rideOptions[0].id);
  const chosen = rideOptions.find((option) => option.id === selected);

  return (
    <>
      <TopBar />
      <main className="page" id="ride">
        <div className="map">
          <img className="map__art" src="./map.svg" alt="" />
          <TripSummary origin={trip.origin} destination={trip.destination} distanceKm={trip.distanceKm} />
        </div>
        <div className="sheet">
          <Panel
            title="نوع سفر را انتخاب کنید"
            footer={
              <button className="confirm" type="button">
                درخواست {chosen?.name}
              </button>
            }
          >
            {rideOptions.map((option) => (
              <ServiceOption
                key={option.id}
                id={option.id}
                name={option.name}
                price={option.price}
                minutes={option.minutes}
                selected={option.id === selected}
                onSelect={setSelected}
                disabled={option.disabled}
              >
                {option.note}
              </ServiceOption>
            ))}
          </Panel>
          <Panel title="روش پرداخت">
            <label className="pay">
              <input className="pay__radio" type="radio" name="pay" defaultChecked />
              <span className="pay__name">کیف پول تپسی</span>
              <span className="pay__note">موجودی: {formatToman(wallet.balance)}</span>
            </label>
            <label className="pay">
              <input className="pay__radio" type="radio" name="pay" />
              <span className="pay__name">پرداخت نقدی</span>
              <span className="pay__note">به راننده، در پایان سفر</span>
            </label>
          </Panel>
        </div>
      </main>
    </>
  );
}
