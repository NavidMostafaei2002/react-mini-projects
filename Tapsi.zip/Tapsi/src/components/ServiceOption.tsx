import type { ReactNode } from "react";
import { formatToman, toFa } from "../format";

// TODO: finish the props type and the component.
//   - ServiceOptionProps also needs price, minutes, selected and onSelect, and
//     two optional props: disabled (false when it is left out) and children.
//   - Return one <button type="button" className="option"> with the icon, the
//     name, the wait time, the price and, only when there are children, the
//     extra note, in the order the statement gives.
//   - A click calls onSelect with this option's id. The option never decides
//     on its own that it is selected; it only shows the `selected` prop.

export type ServiceOptionProps = {
  id: string;
  name: string;
  price: number;
  minutes: number;
  selected: boolean;
  onSelect: (id: string) => void;
  disabled?: boolean;
  children?: ReactNode;
};

export default function ServiceOption({
  id,
  name,
  minutes,
  price,
  selected,
  onSelect,
  disabled,
  children,
}: ServiceOptionProps) {
  return (
    <button
      type="button"
      className={`option ${selected ? "option--selected" : ""}`}
      aria-pressed={selected}
      disabled={disabled}
      onClick={() => {
        onSelect(id);
      }}
    >
      <img className="option__icon" src={`./cars/${id}.svg`} alt="" />
      <span className="option__name">{name}</span>
      <span className="option__eta">{toFa(minutes)} دقیقه</span>
      <strong className="option__price">{formatToman(price)}</strong>
      {children && <span className="option__extra">{children}</span>}
    </button>
  );
}
