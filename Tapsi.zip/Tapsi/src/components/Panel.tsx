import { Children, type ReactNode } from "react";

// TODO: finish the props type and the component.
//   - PanelProps also needs `children` (required) and `footer` (optional),
//     both of type ReactNode.
//   - Return a <section className="panel"> with the title in h2.panel__title,
//     the children in div.panel__body and, only when `footer` is given, the
//     footer in div.panel__footer.
// src/components/TripSummary.tsx shows typed props and an optional prop.

export type PanelProps = {
  title: string;
  children: ReactNode;
  footer?: ReactNode;
};

export default function Panel({ title, children, footer }: PanelProps) {
  return (
    <section className="panel">
      <h2 className="panel__title">{title}</h2>
      <div className="panel__body">{children}</div>
      {footer && <div className="panel__footer">{footer}</div>}
    </section>
  );
}
