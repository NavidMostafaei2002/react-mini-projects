// The site's top bar. This file is fixed; do not change it.
export default function TopBar() {
  return (
    <header className="topbar">
      <div className="topbar__inner">
        <a className="topbar__brand" href="#top">
          <img className="topbar__logo" src="./logo.png" alt="تپسی" />
        </a>
        <nav className="topbar__nav" aria-label="بخش‌های تپسی">
          <a href="#ride" className="is-current">
            درخواست سفر
          </a>
          <a href="#trips">سفرهای من</a>
          <a href="#wallet">کیف پول</a>
          <a href="#support">پشتیبانی</a>
        </nav>
        <a className="topbar__user" href="#profile">
          <span className="topbar__avatar" aria-hidden="true">
            م
          </span>
          مهسا کریمی
        </a>
      </div>
    </header>
  );
}
