import { formatKm } from "../format";

// A worked example of a component with typed props:
//   - TripSummaryProps names every prop and its type, and is exported
//   - the props are destructured right in the parameter list
//   - `when` is optional; App leaves it out, so the default value is used
// This file is fixed; do not change it.
export type TripSummaryProps = {
  origin: string;
  destination: string;
  distanceKm: number;
  when?: string;
};

export default function TripSummary({ origin, destination, distanceKm, when = "همین حالا" }: TripSummaryProps) {
  return (
    <section className="trip" aria-label="مسیر سفر">
      <ol className="trip__route">
        <li className="trip__stop trip__stop--origin">
          <span className="trip__label">مبدأ</span>
          <span className="trip__place">{origin}</span>
        </li>
        <li className="trip__stop trip__stop--destination">
          <span className="trip__label">مقصد</span>
          <span className="trip__place">{destination}</span>
        </li>
      </ol>
      <p className="trip__meta">
        <span>{formatKm(distanceKm)} کیلومتر</span>
        <span>زمان حرکت: {when}</span>
      </p>
    </section>
  );
}
