// This file is fixed; do not change it.

const DIGITS = "۰۱۲۳۴۵۶۷۸۹";

/** Writes every digit of a number or a string with Persian digits. */
export function toFa(value: number | string): string {
  return String(value).replace(/\d/g, (d) => DIGITS[Number(d)]);
}

/** A price in toman: Persian digits, the Persian thousands separator and the currency word. */
export function formatToman(value: number): string {
  return `${toFa(Math.round(value).toLocaleString("en-US")).replace(/,/g, "٬")} تومان`;
}

/** A distance in kilometres with one decimal place and the Persian decimal separator. */
export function formatKm(value: number): string {
  return toFa(value.toFixed(1)).replace(".", "٫");
}
