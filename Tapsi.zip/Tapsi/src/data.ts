// This file is fixed; do not change it. The judge loads other ride types in its place.

export type RideOption = {
  id: string;
  name: string;
  price: number;
  minutes: number;
  note?: string;
  disabled?: boolean;
};

export type Trip = {
  origin: string;
  destination: string;
  distanceKm: number;
};

export const trip: Trip = {
  origin: "میدان ونک، خیابان ملاصدرا",
  destination: "فرودگاه مهرآباد، ترمینال ۴",
  distanceKm: 14.2,
};

export const wallet = {
  balance: 240000,
};

export const rideOptions: RideOption[] = [
  { id: "classic", name: "کلاسیک", price: 186000, minutes: 4 },
  { id: "eco", name: "اقتصادی", price: 158000, minutes: 7, note: "۱۵٪ ارزان‌تر" },
  { id: "plus", name: "تپسی‌پلاس", price: 248000, minutes: 5, note: "خودروهای نو و جادار" },
  { id: "women", name: "تپسی بانوان", price: 192000, minutes: 9, note: "با رانندهٔ خانم" },
  { id: "moto", name: "موتور", price: 96000, minutes: 3, note: "فقط یک مسافر" },
  { id: "van", name: "ون", price: 340000, minutes: 15, note: "در این مسیر فعال نیست", disabled: true },
];
