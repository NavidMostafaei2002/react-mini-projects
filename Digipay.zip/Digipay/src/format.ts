// This file is fixed; do not change it.

const DIGITS = "۰۱۲۳۴۵۶۷۸۹";

/** Writes every digit of a number or a string with Persian digits. */
export function toFa(value: number | string): string {
  return String(value).replace(/\d/g, (d) => DIGITS[Number(d)]);
}

/** A whole number with Persian digits and the Persian thousands separator. */
export function formatNumber(value: number): string {
  return toFa(Math.round(value).toLocaleString("en-US")).replace(/,/g, "٬");
}

/** An amount of money in toman, the way the panel writes it everywhere. */
export function formatToman(value: number): string {
  return `${formatNumber(value)} تومان`;
}
