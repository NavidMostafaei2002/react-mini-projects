import BalanceToggle from "./components/BalanceToggle";
import SideMenu from "./components/SideMenu";
import TopBar from "./components/TopBar";
import TopUp from "./components/TopUp";

// The wallet page of the panel. This file is fixed; do not change it.
export default function App() {
  return (
    <>
      <TopBar />
      <div className="layout">
        <SideMenu />
        <main className="page" id="wallet">
          <div className="page__head">
            <div>
              <h1 className="page__title">افزایش موجودی</h1>
              <p className="page__lead">مبلغ شارژ هر کیف پول را جداگانه انتخاب کنید.</p>
            </div>
            <BalanceToggle total={1_625_000} />
          </div>
          <div className="wallets">
            <div className="wallets__slot">
              <TopUp
                title="کیف پول من"
                balance={1_240_000}
                presets={[100_000, 200_000, 500_000]}
                min={10_000}
                max={2_000_000}
                step={50_000}
              />
            </div>
            <div className="wallets__slot">
              <TopUp
                title="کیف پول خانواده"
                balance={385_000}
                presets={[100_000, 250_000, 400_000]}
                min={50_000}
                max={500_000}
                step={100_000}
              />
            </div>
          </div>
          <p className="page__note">
            <img src="./icons/info.svg" alt="" width={20} height={20} />
            پرداخت از درگاه بانکی انجام می‌شود و مبلغ همان لحظه به کیف پول اضافه می‌شود.
          </p>
        </main>
      </div>
    </>
  );
}
