import { useState } from "react";
import { formatToman } from "../format";

type BalanceToggleProps = {
  total: number;
};

// A worked example of state: the eye button hides and shows the total balance.
//   useState(true) gives the current value and a function that replaces it.
//   Every call to setVisible with a new value makes React call this
//   component again, and the JSX it returns this time shows the value or the
//   dots. The new value is worked out from the current one, so it is passed
//   as an updater function.
// This file is fixed; do not change it.
export default function BalanceToggle({ total }: BalanceToggleProps) {
  const [visible, setVisible] = useState(true);

  return (
    <div className="balance">
      <span className="balance__label">موجودی کل</span>
      <strong className="balance__value">{visible ? formatToman(total) : "••••••"}</strong>
      <button
        type="button"
        className="balance__eye"
        aria-label={visible ? "پنهان کردن موجودی" : "نمایش موجودی"}
        onClick={() => setVisible((current) => !current)}
      >
        <img src={visible ? "./icons/eye-off.svg" : "./icons/eye.svg"} alt="" width={20} height={20} />
      </button>
    </div>
  );
}
