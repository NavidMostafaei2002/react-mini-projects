// The side menu of the panel. This file is fixed; do not change it.
export default function SideMenu() {
  return (
    <aside className="side">
      <nav className="side__nav" aria-label="بخش‌های پنل">
        <a className="side__link is-current" href="#wallet" aria-current="page">
          <span className="side__icon">
            <img src="./icons/wallet.svg" alt="" width={20} height={20} />
          </span>
          کیف پول
        </a>
        <a className="side__link" href="#transactions">
          <span className="side__icon">
            <img src="./icons/transactions.svg" alt="" width={20} height={20} />
          </span>
          تراکنش‌ها
        </a>
        <a className="side__link" href="#installments">
          <span className="side__icon">
            <img src="./icons/installments.svg" alt="" width={20} height={20} />
          </span>
          اقساط
        </a>
        <a className="side__link" href="#cards">
          <span className="side__icon">
            <img src="./icons/cards.svg" alt="" width={20} height={20} />
          </span>
          کارت‌ها
        </a>
      </nav>
    </aside>
  );
}
