import { useState } from "react";
import { formatToman } from "../format";

export type TopUpProps = {
  title: string;
  balance: number;
  presets: number[];
  min: number;
  max: number;
  step: number;
};

// TODO: build the top-up card of one wallet and return it from here.
//   - Keep the chosen amount in state with useState; it starts at presets[0].
//   - A preset chip sets the amount. The + and - buttons move it by `step`,
//     never past `max` or below `min`, and are disabled at those limits.
//   - The balance after the top-up and the text of the pay button are worked
//     out from the amount while rendering.
// src/components/BalanceToggle.tsx shows useState on a smaller part of the page.

export default function TopUp({
  title,
  balance,
  presets,
  min,
  max,
  step,
}: TopUpProps) {
  const [amount, setAmount] = useState<number>(presets[0]);

  const increase = () => setAmount((a) => Math.min(a + step, max));
  const decrease = () => setAmount((a) => Math.max(a - step, min));
  const balanceAfter = balance + amount;

  return (
    <section className="topup">
      <h2 className="topup__title">{title}</h2>
      <p className="topup__balance">
        موجودی فعلی <strong>{formatToman(balance)}</strong>
      </p>
      <div className="topup__presets">
        {presets.map((preset) => (
          <button
            key={preset}
            type="button"
            className="chip"
            aria-pressed={amount === preset}
            onClick={() => setAmount(preset)}
          >
            {formatToman(preset)}
          </button>
        ))}
      </div>
      <div className="stepper">
        <button
          type="button"
          className="stepper__btn stepper__btn--plus"
          aria-label="زیاد کردن مبلغ"
          onClick={increase}
          disabled={amount >= max}
        ></button>
        <output className="stepper__value">{formatToman(amount)}</output>
        <button
          type="button"
          className="stepper__btn stepper__btn--minus"
          aria-label="کم کردن مبلغ"
          onClick={decrease}
          disabled={amount <= min}
        ></button>
      </div>
      <p className="topup__after">
        موجودی بعد از شارژ <strong>{formatToman(balanceAfter)}</strong>
      </p>
      <button type="button" className="topup__pay">
        {`پرداخت ${formatToman(amount)}`}
      </button>
    </section>
  );
}
