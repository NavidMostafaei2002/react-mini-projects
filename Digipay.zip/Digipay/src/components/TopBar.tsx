// The panel's top bar. This file is fixed; do not change it.
export default function TopBar() {
  return (
    <header className="topbar">
      <div className="topbar__inner">
        <a className="topbar__brand" href="#top">
          <img className="topbar__logo" src="./logo.png" alt="دیجی‌پی" />
        </a>
        <span className="topbar__tag">پنل کاربری</span>
        <button type="button" className="topbar__bell" aria-label="اعلان‌ها">
          <img src="./icons/bell.svg" alt="" width={22} height={22} />
        </button>
        <div className="topbar__user">
          <span className="topbar__avatar" aria-hidden="true">
            ن
          </span>
          <span className="topbar__name">نرگس امینی</span>
        </div>
      </div>
    </header>
  );
}
